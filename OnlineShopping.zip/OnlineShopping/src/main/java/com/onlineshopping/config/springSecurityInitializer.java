package com.onlineshopping.config;

public class springSecurityInitializer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
